#!/bin/bash
#
# Starts tomcat.
/sbin/service tomcat start