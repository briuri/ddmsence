var eMail = "\u0064\u0064\u006d\u0073\u0065\u006e\u0063\u0065\u0040\u0075\u0072\u0069\u007a\u006f\u006e\u0065\u002e\u006e\u0065\u0074"

if (parent.location.href.indexOf("urizone.net") != -1) {
	var sc_project=5679800;
	var sc_invisible=0;
	var sc_partition=63;
	var sc_click_stat=1;
	var sc_security="ed77bc6e";
	var sc_text=2;
}