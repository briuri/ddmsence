#!/bin/bash
#
# Cleans the webapps directory.
rm -rf /usr/local/tomcat/webapps-ddmsence/*