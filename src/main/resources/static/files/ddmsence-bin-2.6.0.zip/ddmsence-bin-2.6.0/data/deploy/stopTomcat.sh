#!/bin/bash
#
# Stops tomcat.
/sbin/service tomcat stop