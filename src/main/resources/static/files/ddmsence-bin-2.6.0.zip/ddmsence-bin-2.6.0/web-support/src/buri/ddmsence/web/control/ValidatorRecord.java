package buri.ddmsence.web.control;

import buri.ddmsence.util.Util;

/**
 * Form bean for online DDMS validation
 *
 * @author Brian Uri!
 */
public class ValidatorRecord {

	public static final String TYPE_TEXT = "text";
	public static final String TYPE_URL = "url";
	public static final String DEFAULT_TYPE = TYPE_TEXT;

	private String _type;
	private String _stringRecord;
	private String _url;

	/**
	 * Constructor
	 *
	 * @param type the type of record being submitted.
	 */
	public ValidatorRecord(String type) {
		if (Util.isEmpty(type))
			type = DEFAULT_TYPE;
		_type = type;
	}

	/**
	 * Accessor for the string version of the record.
	 */
	public String getStringRecord() {
		return _stringRecord;
	}

	/**
	 * Accessor for the string version of the record.
	 */
	public void setStringRecord(String stringRecord) {
		_stringRecord = stringRecord;
	}

	/**
	 * Accessor for the type (url, text)
	 */
	public String getType() {
		return _type;
	}

	/**
	 * Accessor for the url
	 */
	public String getUrl() {
		return _url;
	}

	/**
	 * Accessor for the url
	 */
	public void setUrl(String url) {
		_url = url;
	}
}
