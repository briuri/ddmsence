package buri.ddmsence.web.control;

import java.io.ByteArrayOutputStream;
import java.util.Set;

import nu.xom.Document;
import nu.xom.Serializer;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import buri.ddmsence.ddms.InvalidDDMSException;
import buri.ddmsence.ddms.Resource;
import buri.ddmsence.ddms.ValidationMessage;
import buri.ddmsence.ddms.security.ism.ISMVocabulary;
import buri.ddmsence.util.DDMSVersion;
import buri.ddmsence.util.PropertyReader;
import buri.ddmsence.util.Util;

/**
 * Controller class for building DDMS Records
 * 
 * @author Brian Uri!
 */
@Controller
@SessionAttributes({ "resource" })
public class BuilderControl {

	/**
	 * Entry point for creating a new builder
	 */
	@RequestMapping(value = "/builder.uri", method = RequestMethod.GET)
	public String newForm(Model model) {
		Resource.Builder builder = new Resource.Builder();
		model.addAttribute("resource", builder);
		return ("builder");
	}

	/**
	 * Entry point for saving the builder
	 */
	@RequestMapping(value = "/builder.uri", method = RequestMethod.POST)
	public String build(@ModelAttribute("resource") Resource.Builder builder, BindingResult result,
		SessionStatus status, Model model) {
		try {
			DDMSVersion.setCurrentVersion("5.0");
			PropertyReader.setProperty("output.json.prettyPrint", "true");
			PropertyReader.setProperty("output.indexLevel", "1");
			Resource resource = builder.commit();
			if (resource == null)
				throw new InvalidDDMSException("No information was entered to create a DDMS Resource.");
			// Skipping resource.toXML() so I can control formatting.
			Document document = new Document(resource.getXOMElementCopy());
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			Serializer serializer = new Serializer(os, "ISO-8859-1");
			serializer.setIndent(3);
			serializer.setMaxLength(120);
			serializer.write(document);
			model.addAttribute("xml", os.toString());
			model.addAttribute("html", resource.toHTML());
			model.addAttribute("text", resource.toText());
			model.addAttribute("json", resource.toJSON());
			model.addAttribute("warnings", resource.getValidationWarnings());
			return ("builderResult");
		}
		catch (InvalidDDMSException e) {
			ValidationMessage message = ValidationMessage.newError(e.getMessage(), e.getLocator());
			String location = Util.isEmpty(message.getLocator()) ? "unknown location" : message.getLocator();
			result.reject(null, null, "<b>" + message.getType() + "</b> at <code>" + location + "</code>: "
				+ message.getText());
		}
		catch (Exception e) {
			result.reject(e.getMessage());
		}
		return ("builder");
	}

	/**
	 * Accessor for the allowable ownerProducer values
	 */
	@ModelAttribute(value = "ownerProducers")
	private Set<String> getOwnerProducers() {
		return (ISMVocabulary.getEnumerationTokens(DDMSVersion.getVersionFor("5.0"), ISMVocabulary.CVE_OWNER_PRODUCERS));
	}
}